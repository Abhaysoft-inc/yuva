<img src="{{ asset('images/logo.webp') }}" alt="Logo" class="h-16 w-auto">
