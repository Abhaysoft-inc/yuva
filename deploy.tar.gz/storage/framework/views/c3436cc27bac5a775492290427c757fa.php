<img src="<?php echo e(asset('images/logo.webp')); ?>" alt="Logo" class="h-16 w-auto">
<?php /**PATH C:\laragon\www\ngo\resources\views/components/application-logo.blade.php ENDPATH**/ ?>